"""UCSB camera calibration and the authors' *legacy* undistortion.

From the original dataset page (ilab.cs.ucsb.edu/tracking_dataset_ijcv, Web Archive 2016):
the GT homographies (.warps) map *undistorted* frames to the reference frame, and the
undistorted frames were made with an old OpenCV cvInitUndistortMap that had a bug:
it re-centres the output on the image centre ((W-1)/2, (H-1)/2) instead of (cx, cy).
Modern cv2.initUndistortRectifyMap does not reproduce it, so we re-implement the legacy
map here (see original_site/cvundistort_legacy.cpp).
"""
import cv2
import numpy as np

FX, FY, CX, CY = 869.57, 867.528, 299.748, 237.284
K1, K2, P1, P2 = -0.0225415, -0.259618, 0.00320736, -0.000551689


def undist_to_raw(pts, w=640, h=480):
    """Map points in the (legacy-)undistorted image to the raw camera frame."""
    pts = np.asarray(pts, np.float64)
    x = (pts[..., 0] - CX) / FX
    y = (pts[..., 1] - CY) / FY
    r2 = x * x + y * y
    kr = 1 + (K2 * r2 + K1) * r2
    xd = FX * (x * kr + P1 * 2 * x * y + P2 * (r2 + 2 * x * x)) + (w - 1) * 0.5
    yd = FY * (y * kr + P1 * (r2 + 2 * y * y) + P2 * 2 * x * y) + (h - 1) * 0.5
    return np.stack([xd, yd], -1)


_MAPS = {}


def undistort(img):
    """Raw camera frame -> undistorted frame in which the GT homographies are valid."""
    h, w = img.shape[:2]
    if (w, h) not in _MAPS:
        u, v = np.meshgrid(np.arange(w, dtype=np.float64), np.arange(h, dtype=np.float64))
        m = undist_to_raw(np.stack([u, v], -1), w, h).astype(np.float32)
        _MAPS[(w, h)] = (m[..., 0], m[..., 1])
    mx, my = _MAPS[(w, h)]
    return cv2.remap(img, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
