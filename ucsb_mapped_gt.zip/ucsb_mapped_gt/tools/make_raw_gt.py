"""Write GT corners that are valid in the RAW (distorted) jpg frames, for every sequence.

The original GT (groundtruth_warps/*.warps and the MTF-style <seq>.txt) lives in the
legacy-undistorted image. Here each GT corner is mapped back into the raw frame with the
authors' calibration (ucsb_undistort.undist_to_raw). Output keeps the MTF .txt format:
    frame ulx uly urx ury lrx lry llx lly
Two variants per sequence:
    gt_raw/<seq>.txt        the <seq>.txt corners (incl. its quirks) mapped to raw frames
    gt_raw_roi/<seq>.txt    textureROI from the .warps homography mapped to raw frames,
                            corners in a fixed physical order (no label jumps)
Note: in the raw frame the texture edges are slightly curved; 4 corners are the best quad.
Usage: python make_raw_gt.py <ucsb_root> <out_dir>
"""
import sys
from pathlib import Path

import numpy as np

from ucsb_undistort import undist_to_raw

TEXTURE = np.array([[76.2, 76.2], [279.4, 76.2], [279.4, 215.9], [76.2, 215.9]])  # textureROI, ref mm


def write(path, names, corners):
    with open(path, "w") as f:
        f.write("frame   ulx     uly     urx     ury     lrx     lry     llx     lly     \n")
        for n, c in zip(names, corners):
            f.write(n + "\t" + "\t".join(f"{v:.2f}" for v in c.ravel()) + "\t\n")


def main(root, out):
    (out / "gt_raw").mkdir(parents=True, exist_ok=True)
    (out / "gt_raw_roi").mkdir(parents=True, exist_ok=True)
    seqs = [l.split()[0] for l in open(root / "n_frames.txt") if l.strip()]
    for seq in seqs:
        names = np.loadtxt(root / f"{seq}.txt", skiprows=1, usecols=0, dtype=str)
        c = np.loadtxt(root / f"{seq}.txt", skiprows=1, usecols=range(1, 9)).reshape(-1, 4, 2)
        W = np.loadtxt(root / "groundtruth_warps" / f"{seq}.warps").reshape(-1, 3, 3)
        write(out / "gt_raw" / f"{seq}.txt", names, undist_to_raw(c))
        roi = []
        for H in W:
            q = np.c_[TEXTURE, np.ones(4)] @ np.linalg.inv(H).T
            roi.append(q[:, :2] / q[:, 2:])
        write(out / "gt_raw_roi" / f"{seq}.txt", names, undist_to_raw(np.array(roi)))
        shift = np.abs(undist_to_raw(c) - c).max(axis=(1, 2))
        print(f"{seq:28s} {len(names):4d} frames   raw-vs-original corner shift: "
              f"mean {shift.mean():5.1f}  max {shift.max():5.1f} px")


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
